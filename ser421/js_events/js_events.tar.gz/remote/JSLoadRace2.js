console.log('EXTERNAL SCRIPT EXECUTED OFF ' + document.domain);
alert(document.domain);
